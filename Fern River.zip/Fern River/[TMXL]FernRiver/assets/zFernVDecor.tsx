<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="zFernVDecor" tilewidth="16" tileheight="16" tilecount="800" columns="20">
 <image source="zFernVDecor.png" width="320" height="640"/>
</tileset>
