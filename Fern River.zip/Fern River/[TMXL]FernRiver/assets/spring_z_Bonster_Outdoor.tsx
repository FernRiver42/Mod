<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="spring_z_Bonster_Outdoor" tilewidth="16" tileheight="16" tilecount="1024" columns="32">
 <image source="spring_z_Bonster_Outdoor.png" width="512" height="512"/>
 <tile id="544">
  <animation>
   <frame tileid="544" duration="250"/>
   <frame tileid="548" duration="250"/>
   <frame tileid="552" duration="250"/>
   <frame tileid="556" duration="250"/>
  </animation>
 </tile>
 <tile id="545">
  <animation>
   <frame tileid="545" duration="250"/>
   <frame tileid="549" duration="250"/>
   <frame tileid="553" duration="250"/>
   <frame tileid="557" duration="250"/>
  </animation>
 </tile>
 <tile id="546">
  <animation>
   <frame tileid="546" duration="250"/>
   <frame tileid="550" duration="250"/>
   <frame tileid="554" duration="250"/>
   <frame tileid="558" duration="250"/>
  </animation>
 </tile>
 <tile id="576">
  <animation>
   <frame tileid="576" duration="250"/>
   <frame tileid="580" duration="250"/>
   <frame tileid="584" duration="250"/>
   <frame tileid="588" duration="250"/>
  </animation>
 </tile>
 <tile id="577">
  <animation>
   <frame tileid="577" duration="250"/>
   <frame tileid="581" duration="250"/>
   <frame tileid="585" duration="250"/>
   <frame tileid="589" duration="250"/>
  </animation>
 </tile>
 <tile id="578">
  <animation>
   <frame tileid="578" duration="250"/>
   <frame tileid="582" duration="250"/>
   <frame tileid="586" duration="250"/>
   <frame tileid="590" duration="250"/>
  </animation>
 </tile>
</tileset>
