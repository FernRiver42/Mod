<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="zFROutdoors" tilewidth="16" tileheight="16" tilecount="2320" columns="40">
 <image source="Spring_zFROutdoors.png" width="640" height="928"/>
 <tile id="9">
  <properties>
   <property name="Passable" value="T"/>
  </properties>
 </tile>
 <tile id="224">
  <animation>
   <frame tileid="224" duration="250"/>
   <frame tileid="225" duration="250"/>
   <frame tileid="226" duration="250"/>
   <frame tileid="227" duration="250"/>
   <frame tileid="228" duration="250"/>
  </animation>
 </tile>
 <tile id="264">
  <animation>
   <frame tileid="264" duration="250"/>
   <frame tileid="265" duration="250"/>
   <frame tileid="266" duration="250"/>
   <frame tileid="267" duration="250"/>
   <frame tileid="268" duration="250"/>
  </animation>
 </tile>
 <tile id="282">
  <animation>
   <frame tileid="282" duration="250"/>
   <frame tileid="288" duration="250"/>
   <frame tileid="294" duration="250"/>
   <frame tileid="300" duration="250"/>
  </animation>
 </tile>
 <tile id="283">
  <animation>
   <frame tileid="283" duration="250"/>
   <frame tileid="289" duration="250"/>
   <frame tileid="295" duration="250"/>
   <frame tileid="301" duration="250"/>
  </animation>
 </tile>
 <tile id="284">
  <animation>
   <frame tileid="284" duration="250"/>
   <frame tileid="290" duration="250"/>
   <frame tileid="296" duration="250"/>
   <frame tileid="302" duration="250"/>
  </animation>
 </tile>
 <tile id="285">
  <animation>
   <frame tileid="285" duration="250"/>
   <frame tileid="291" duration="250"/>
   <frame tileid="297" duration="250"/>
   <frame tileid="303" duration="250"/>
  </animation>
 </tile>
 <tile id="322">
  <animation>
   <frame tileid="322" duration="250"/>
   <frame tileid="328" duration="250"/>
   <frame tileid="334" duration="250"/>
   <frame tileid="340" duration="250"/>
  </animation>
 </tile>
 <tile id="323">
  <animation>
   <frame tileid="323" duration="250"/>
   <frame tileid="329" duration="250"/>
   <frame tileid="335" duration="250"/>
   <frame tileid="341" duration="250"/>
  </animation>
 </tile>
 <tile id="324">
  <animation>
   <frame tileid="324" duration="250"/>
   <frame tileid="330" duration="250"/>
   <frame tileid="336" duration="250"/>
   <frame tileid="342" duration="250"/>
  </animation>
 </tile>
 <tile id="325">
  <animation>
   <frame tileid="325" duration="250"/>
   <frame tileid="331" duration="250"/>
   <frame tileid="337" duration="250"/>
   <frame tileid="343" duration="250"/>
  </animation>
 </tile>
 <tile id="362">
  <animation>
   <frame tileid="362" duration="250"/>
   <frame tileid="368" duration="250"/>
   <frame tileid="374" duration="250"/>
   <frame tileid="380" duration="250"/>
  </animation>
 </tile>
 <tile id="363">
  <animation>
   <frame tileid="363" duration="250"/>
   <frame tileid="369" duration="250"/>
   <frame tileid="375" duration="250"/>
   <frame tileid="381" duration="250"/>
  </animation>
 </tile>
 <tile id="364">
  <animation>
   <frame tileid="364" duration="250"/>
   <frame tileid="370" duration="250"/>
   <frame tileid="376" duration="250"/>
   <frame tileid="382" duration="250"/>
  </animation>
 </tile>
 <tile id="365">
  <animation>
   <frame tileid="365" duration="250"/>
   <frame tileid="371" duration="250"/>
   <frame tileid="377" duration="250"/>
   <frame tileid="383" duration="250"/>
  </animation>
 </tile>
 <tile id="402">
  <animation>
   <frame tileid="402" duration="250"/>
   <frame tileid="408" duration="250"/>
   <frame tileid="414" duration="250"/>
   <frame tileid="420" duration="250"/>
  </animation>
 </tile>
 <tile id="403">
  <animation>
   <frame tileid="403" duration="250"/>
   <frame tileid="409" duration="250"/>
   <frame tileid="415" duration="250"/>
   <frame tileid="421" duration="250"/>
  </animation>
 </tile>
 <tile id="404">
  <animation>
   <frame tileid="404" duration="250"/>
   <frame tileid="410" duration="250"/>
   <frame tileid="416" duration="250"/>
   <frame tileid="422" duration="250"/>
  </animation>
 </tile>
 <tile id="405">
  <animation>
   <frame tileid="405" duration="250"/>
   <frame tileid="411" duration="250"/>
   <frame tileid="417" duration="250"/>
   <frame tileid="423" duration="250"/>
  </animation>
 </tile>
 <tile id="442">
  <animation>
   <frame tileid="442" duration="250"/>
   <frame tileid="448" duration="250"/>
   <frame tileid="454" duration="250"/>
   <frame tileid="460" duration="250"/>
  </animation>
 </tile>
 <tile id="443">
  <animation>
   <frame tileid="443" duration="250"/>
   <frame tileid="449" duration="250"/>
   <frame tileid="455" duration="250"/>
   <frame tileid="461" duration="250"/>
  </animation>
 </tile>
 <tile id="444">
  <animation>
   <frame tileid="444" duration="250"/>
   <frame tileid="450" duration="250"/>
   <frame tileid="456" duration="250"/>
   <frame tileid="462" duration="250"/>
  </animation>
 </tile>
 <tile id="445">
  <animation>
   <frame tileid="445" duration="250"/>
   <frame tileid="451" duration="250"/>
   <frame tileid="457" duration="250"/>
   <frame tileid="463" duration="250"/>
  </animation>
 </tile>
 <tile id="481">
  <animation>
   <frame tileid="481" duration="250"/>
   <frame tileid="487" duration="250"/>
   <frame tileid="493" duration="250"/>
   <frame tileid="499" duration="250"/>
  </animation>
 </tile>
 <tile id="482">
  <animation>
   <frame tileid="482" duration="250"/>
   <frame tileid="488" duration="250"/>
   <frame tileid="494" duration="250"/>
   <frame tileid="500" duration="250"/>
  </animation>
 </tile>
 <tile id="483">
  <animation>
   <frame tileid="483" duration="250"/>
   <frame tileid="489" duration="250"/>
   <frame tileid="495" duration="250"/>
   <frame tileid="501" duration="250"/>
  </animation>
 </tile>
 <tile id="484">
  <animation>
   <frame tileid="484" duration="250"/>
   <frame tileid="490" duration="250"/>
   <frame tileid="496" duration="250"/>
   <frame tileid="502" duration="250"/>
  </animation>
 </tile>
 <tile id="485">
  <animation>
   <frame tileid="485" duration="250"/>
   <frame tileid="491" duration="250"/>
   <frame tileid="497" duration="250"/>
   <frame tileid="503" duration="250"/>
  </animation>
 </tile>
 <tile id="486">
  <animation>
   <frame tileid="486" duration="250"/>
   <frame tileid="492" duration="250"/>
   <frame tileid="498" duration="250"/>
   <frame tileid="504" duration="250"/>
  </animation>
 </tile>
 <tile id="521">
  <animation>
   <frame tileid="521" duration="250"/>
   <frame tileid="527" duration="250"/>
   <frame tileid="533" duration="250"/>
   <frame tileid="539" duration="250"/>
  </animation>
 </tile>
 <tile id="522">
  <animation>
   <frame tileid="522" duration="250"/>
   <frame tileid="528" duration="250"/>
   <frame tileid="534" duration="250"/>
   <frame tileid="540" duration="250"/>
  </animation>
 </tile>
 <tile id="523">
  <animation>
   <frame tileid="523" duration="250"/>
   <frame tileid="529" duration="250"/>
   <frame tileid="535" duration="250"/>
   <frame tileid="541" duration="250"/>
  </animation>
 </tile>
 <tile id="524">
  <animation>
   <frame tileid="524" duration="250"/>
   <frame tileid="530" duration="250"/>
   <frame tileid="536" duration="250"/>
   <frame tileid="542" duration="250"/>
  </animation>
 </tile>
 <tile id="525">
  <animation>
   <frame tileid="525" duration="250"/>
   <frame tileid="531" duration="250"/>
   <frame tileid="537" duration="250"/>
   <frame tileid="543" duration="250"/>
  </animation>
 </tile>
 <tile id="526">
  <animation>
   <frame tileid="526" duration="250"/>
   <frame tileid="532" duration="250"/>
   <frame tileid="538" duration="250"/>
   <frame tileid="544" duration="250"/>
  </animation>
 </tile>
 <tile id="584">
  <animation>
   <frame tileid="584" duration="250"/>
   <frame tileid="586" duration="250"/>
   <frame tileid="626" duration="250"/>
   <frame tileid="666" duration="250"/>
   <frame tileid="706" duration="250"/>
   <frame tileid="666" duration="250"/>
   <frame tileid="626" duration="250"/>
   <frame tileid="586" duration="250"/>
  </animation>
 </tile>
 <tile id="840">
  <animation>
   <frame tileid="840" duration="250"/>
   <frame tileid="841" duration="250"/>
   <frame tileid="842" duration="250"/>
   <frame tileid="843" duration="250"/>
   <frame tileid="844" duration="250"/>
   <frame tileid="845" duration="250"/>
   <frame tileid="846" duration="250"/>
   <frame tileid="847" duration="250"/>
   <frame tileid="848" duration="250"/>
   <frame tileid="849" duration="250"/>
   <frame tileid="850" duration="250"/>
   <frame tileid="851" duration="250"/>
   <frame tileid="852" duration="250"/>
   <frame tileid="853" duration="250"/>
   <frame tileid="854" duration="250"/>
   <frame tileid="855" duration="250"/>
  </animation>
 </tile>
 <tile id="841">
  <animation>
   <frame tileid="855" duration="250"/>
   <frame tileid="854" duration="250"/>
   <frame tileid="853" duration="250"/>
   <frame tileid="852" duration="250"/>
   <frame tileid="851" duration="250"/>
   <frame tileid="850" duration="250"/>
   <frame tileid="849" duration="250"/>
   <frame tileid="848" duration="250"/>
   <frame tileid="847" duration="250"/>
   <frame tileid="846" duration="250"/>
   <frame tileid="845" duration="250"/>
   <frame tileid="844" duration="250"/>
   <frame tileid="843" duration="250"/>
   <frame tileid="842" duration="250"/>
   <frame tileid="841" duration="250"/>
   <frame tileid="840" duration="250"/>
  </animation>
 </tile>
</tileset>
