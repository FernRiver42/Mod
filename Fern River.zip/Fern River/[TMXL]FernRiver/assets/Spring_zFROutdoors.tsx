<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="Spring_zFROutdoors" tilewidth="16" tileheight="16" tilecount="2320" columns="40">
 <image source="Spring_zFROutdoors.png" width="640" height="928"/>
</tileset>
