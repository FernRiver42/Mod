<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="TownOutdoorsFernRiver" tilewidth="16" tileheight="16" tilecount="1600" columns="40">
 <image source="TownOutdoorsFernRiver.png" width="640" height="640"/>
</tileset>
