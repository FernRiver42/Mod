<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="walls_and_floors" tilewidth="16" tileheight="16" tilecount="560" columns="16">
 <image source="walls_and_floors.png" width="256" height="560"/>
</tileset>
