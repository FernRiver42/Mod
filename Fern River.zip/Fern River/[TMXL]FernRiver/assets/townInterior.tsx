<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="townInterior" tilewidth="16" tileheight="16" tilecount="2176" columns="32">
 <image source="townInterior.png" width="512" height="1088"/>
 <tile id="581">
  <animation>
   <frame tileid="550" duration="250"/>
   <frame tileid="550" duration="250"/>
   <frame tileid="581" duration="250"/>
   <frame tileid="581" duration="250"/>
   <frame tileid="582" duration="250"/>
   <frame tileid="582" duration="250"/>
   <frame tileid="581" duration="250"/>
   <frame tileid="581" duration="250"/>
  </animation>
 </tile>
</tileset>
