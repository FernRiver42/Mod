<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="zFRInterior" tilewidth="16" tileheight="16" tilecount="3200" columns="40">
 <image source="zFRInterior.png" width="640" height="1280"/>
</tileset>
