<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="SpringzFernVDecor" tilewidth="16" tileheight="16" tilecount="800" columns="20">
 <image source="SpringzFernVDecor.png" width="320" height="640"/>
 <tile id="15">
  <properties>
   <property name="Passable" value="T"/>
  </properties>
 </tile>
</tileset>
